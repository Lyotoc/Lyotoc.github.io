# 设置 Protobuf 文件的根目录
$ProtoDir = $args[0]

# 设置要生成的代码语言
$Language = $args[1]

# 检查是否提供了 Protobuf 目录和语言参数
if ([string]::IsNullOrEmpty($ProtoDir) -or [string]::IsNullOrEmpty($Language)) {
    Write-Host "请提供 Protobuf 文件的目录和目标语言作为参数。"
    Write-Host "用法: ./script.ps1 <Proto目录> <语言 (go, java, javascript)>"
    exit 1
}

# 根据语言选择不同的 protoc 参数
switch ($Language) {
    "go" {
        $GoOut = "--go_out=."
        $GoOpt = "--go_opt=paths=source_relative"
        $GoGrpcOut = "--go-grpc_out=."
        $GoGrpcOpt = "--go-grpc_opt=paths=source_relative"
    }
    "java" {
        $JavaOut = "--java_out=."
    }
    "javascript" {
        $JsOut = "--js_out=import_style=commonjs,binary:." # 你可能需要调整参数
    }
    default {
        Write-Host "不支持的语言: $Language"
        exit 1
    }
}

# 使用 Get-ChildItem 查找所有 .proto 文件
$ProtoFiles = Get-ChildItem -Path $ProtoDir -Filter "*.proto" -Recurse

# 循环处理每个 .proto 文件
foreach ($ProtoFile in $ProtoFiles) {
    # 构建 protoc 命令参数数组
    $ProtocArguments = @(
        "--proto_path=$ProtoDir"  # 添加 Protobuf 搜索路径
    )

    # 添加语言相关的参数
    switch ($Language) {
        "go" {
            $ProtocArguments += $GoOut, $GoOpt, $GoGrpcOut, $GoGrpcOpt
        }
        "java" {
            $ProtocArguments += $JavaOut
        }
        "javascript" {
            $ProtocArguments += $JsOut
        }
    }

    # 添加 .proto 文件名
    $ProtocArguments += $ProtoFile.FullName

    # 执行 protoc 命令
    Write-Host "正在处理: $($ProtoFile.FullName)"
    & protoc @ProtocArguments

    # 检查 protoc 命令是否成功执行
    if ($LastExitCode -ne 0) {
        Write-Error "protoc 命令执行失败，文件: $($ProtoFile.FullName)"
    }
}

Write-Host "Protobuf 代码生成完成。"
