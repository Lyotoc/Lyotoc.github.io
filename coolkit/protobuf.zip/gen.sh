#!/bin/bash

PROTO_DIR=$1
for PROTO_FILE in $(find "$PROTO_DIR" -name "*.proto"); do
    # Generate Go files
    protoc --go_out=. --go_opt=paths=source_relative --go-grpc_out=. --go-grpc_opt=paths=source_relative "$PROTO_FILE"
    
    # Generate JS files
    pbjs -t static-module -w commonjs -o "../client/src/protobuf/$(basename ${PROTO_FILE%.*}).js" "$PROTO_FILE"
done
